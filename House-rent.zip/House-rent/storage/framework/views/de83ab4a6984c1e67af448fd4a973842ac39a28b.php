 
<?php $__env->startSection('content'); ?>
<div class="container custom-rent mb-5" style="min-height: 480px !important">
    <h1 class="mb-5 text-center featurette-heading"  style="font-size:50px;margin-top:40px" >Search Result</h1>  
      <div class="rentals " style="display: flex;flex-flow:row;justify-content:start;flex-wrap:wrap;"> 
         
  
        <?php $__currentLoopData = $rents; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?> 
        
  
       <div class="card text-center" style="width: 20rem;display:inline-block;margin:40px 2px">
        <a href="/detail/<?php echo e($item['id']); ?>" style="color: black;text-decoration:none"> <img class="card-img-top" src="<?php echo e($item['gallery']); ?>" alt="Card image cap" height="250">    </a>
        <a href="/detail/<?php echo e($item['id']); ?>" style="color: black;text-decoration:none">
          <div class="card-body">
              <h5><?php echo e($item['category']); ?></h5>
            <p class="card-text"><?php echo e($item['price']); ?></p>
            <p><?php echo e($item['address']); ?></p>
          </div>
        </a>
        </div>
  
  
  
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>  
        </div>
        <hr class="mt-5">
      </div>
 <?php $__env->stopSection(); ?>   



<?php echo $__env->make('layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Laravel\House-Rent\House-Rental-Site\House-rent\resources\views/search.blade.php ENDPATH**/ ?>